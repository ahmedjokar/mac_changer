import os
import random
import subprocess
import re
import pyfiglet
import termcolor

rand_mac="%02x:%02x:%02x:%02x:%02x:%02x" % (
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255),
        random.randint(0, 255)
        )



def decor (name,color):
    print('='*55,end='\n\n')
    print(termcolor.colored(pyfiglet.figlet_format(name),color=color))
    print('='*55,end='\n\n')
    
def main():
    decor('Main-Menu','red')
    print ('[1]eth0\n[2]wlan0\n[3]Exit',end='\n\n')

    choise = int(input('select interface:'.title()).strip())
    
    if choise == 1 :
        output= subprocess.check_output(f'ifconfig eth0',shell=True).decode()
        mac =(re.search("ether (.+) ", output).group().split()[1].strip())
        
        decor('eth0','green')
        print (f'Current MAC : {mac}'.center(60),end='\n\n')

        print('[1]Change MAC\n[2]Back',end='\n\n')
        
        choise = int(input('select:'.title()).strip())
        
        if choise == 1 :
            os.system('sudo ifconfig eth0 down')
            os.system(f'sudo ifconfig eth0 hw ether {rand_mac}')
            os.system('sudo ifconfig eth0 up')
            print (f'Current MAC : {rand_mac}'.center(60),end='\n\n')    
        
        if choise == 2 :
            main()

    if choise == 2 :
        output= subprocess.check_output(f'ifconfig wlan0',shell=True).decode()
        mac =(re.search("ether (.+) ", output).group().split()[1].strip())
        
        
        decor('wlan0','yellow')
        print (f'Current MAC : {mac}'.center(60),end='\n\n')

        print('[1]Change MAC\n[2]Back',end='\n\n')
        
        choise = int(input('select:'.title()).strip())
        
        if choise == 1 :
            os.system('sudo ifconfig wlan0 down')
            os.system(f'sudo ifconfig wlan0 hw ether {rand_mac}')
            os.system('sudo ifconfig wlan0 up')
            print (f'Current MAC : {rand_mac}'.center(60),end='\n\n')    
        
        if choise == 2 :
            main()
            
main()







    
    


#Choise = int(input('select interface: '.title()).strip())


    
